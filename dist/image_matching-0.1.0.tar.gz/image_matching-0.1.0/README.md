# Image Matching

Image matching component.

## Installation

```bash
pip install image-matching
```
